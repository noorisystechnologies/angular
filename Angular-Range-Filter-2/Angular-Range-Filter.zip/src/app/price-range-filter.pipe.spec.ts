import { PriceRangeFilterPipe } from './price-range-filter.pipe';

describe('PriceRangeFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PriceRangeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
